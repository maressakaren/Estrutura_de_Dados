#ifndef __principal_h_
#define __principal_h_
#include "TADPilha.h"
void hanoi(int n,pilha inicio,pilha meio, pilha fim);
void movimentos(int n,char*inicio, char*meio,char*fim);
void iniciarTorre(char *argv[], int argc);
int funcAtoi(char*str);

#endif

