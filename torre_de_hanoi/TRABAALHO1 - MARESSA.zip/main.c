#include<stdlib.h>
#include<stdio.h>
#include <time.h>  
#include "hanoi.h"  
#define BILLION  1000000000.0


int main(int argc, char* argv[]){
    
    iniciarTorre(argv,argc);

     
	return 0;
}